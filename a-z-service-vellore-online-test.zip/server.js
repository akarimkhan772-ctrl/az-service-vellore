const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "requests.json");

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]");

app.use(express.json({limit:"50kb"}));
app.use(express.static(path.join(__dirname, "public")));

function readRequests() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return []; }
}
function writeRequests(items) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(items, null, 2));
}
function clean(v, max=1000) {
  return typeof v === "string" ? v.trim().slice(0,max) : "";
}

app.get("/api/health", (req,res) => {
  res.json({ok:true, service:"A-Z Service backend"});
});

app.post("/api/requests", (req,res) => {
  const body=req.body || {};
  if (!clean(body.name,100) || !clean(body.phone,40)) {
    return res.status(400).json({error:"Name and mobile/WhatsApp are required."});
  }

  const items=readRequests();
  const requestId="AZ-"+new Date().toISOString().slice(0,10).replace(/-/g,"")+"-"+crypto.randomBytes(3).toString("hex").toUpperCase();

  const item={
    requestId,
    createdAt:new Date().toISOString(),
    status:"new",
    name:clean(body.name,100),
    phone:clean(body.phone,40),
    country:clean(body.country,80),
    date:clean(body.date,30),
    customerType:clean(body.customerType,80),
    services:Array.isArray(body.services) ? body.services.map(x=>clean(x,100)).slice(0,30) : [],
    message:clean(body.message,2000)
  };

  items.unshift(item);
  writeRequests(items);
  res.status(201).json({ok:true,requestId});
});

/*
  Simple admin API for testing.
  IMPORTANT: before production, replace this with real authentication and a database.
*/
app.get("/api/requests", (req,res) => {
  const key=process.env.ADMIN_KEY;
  if (!key || req.get("x-admin-key") !== key) {
    return res.status(401).json({error:"Unauthorized"});
  }
  res.json(readRequests());
});

app.patch("/api/requests/:id", (req,res) => {
  const key=process.env.ADMIN_KEY;
  if (!key || req.get("x-admin-key") !== key) return res.status(401).json({error:"Unauthorized"});
  const allowed=["new","contacted","confirmed","progress","completed","cancelled"];
  const status=clean(req.body && req.body.status,30);
  if(!allowed.includes(status)) return res.status(400).json({error:"Invalid status"});
  const items=readRequests();
  const item=items.find(x=>x.requestId===req.params.id);
  if(!item) return res.status(404).json({error:"Request not found"});
  item.status=status;
  item.updatedAt=new Date().toISOString();
  writeRequests(items);
  res.json({ok:true,item});
});


app.patch("/api/requests/:id", (req,res) => {
  const key=process.env.ADMIN_KEY;
  if (!key || req.get("x-admin-key") !== key) return res.status(401).json({error:"Unauthorized"});
  const allowed=["new","contacted","confirmed","progress","completed","cancelled"];
  const status=typeof req.body?.status==="string" ? req.body.status : "";
  if(!allowed.includes(status)) return res.status(400).json({error:"Invalid status"});
  const items=readRequests();
  const i=items.findIndex(x=>x.requestId===req.params.id);
  if(i<0) return res.status(404).json({error:"Request not found"});
  items[i].status=status;
  items[i].updatedAt=new Date().toISOString();
  writeRequests(items);
  res.json({ok:true,item:items[i]});
});

app.get("/{*splat}", (req,res) => {
  res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`A-Z Service running at http://localhost:${PORT}`);
});
