# A-Z Service — Vellore Full-Stack Website

Testing deployment package for the A-Z Service website.

## Local run
1. Install Node.js.
2. Open this folder in VS Code Terminal.
3. Run `npm install`.
4. Set an admin key in PowerShell: `$env:ADMIN_KEY="your-private-admin-key"`
5. Run `npm start`.
6. Open http://localhost:3000
7. Admin: http://localhost:3000/admin/

## Render test deployment
- Create a Render Web Service from this repository.
- Build Command: `npm install`
- Start Command: `npm start`
- Health Check Path: `/api/health`
- Add environment variable `ADMIN_KEY` with a private value.
- Render supplies `PORT`; the app binds to `0.0.0.0`.

## Important testing limitation
Customer requests are currently stored in `data/requests.json`. Render's normal service filesystem is ephemeral, so this is suitable for testing only. Before a real public launch, move requests to a managed database (such as PostgreSQL/Supabase), add proper authentication, rate limiting, backups, and privacy/consent controls.

For appointment, visa/immigration, financial, currency, money-transfer/withdrawal and similar services, connect only to authorized providers/processes and do not promise guaranteed outcomes.
